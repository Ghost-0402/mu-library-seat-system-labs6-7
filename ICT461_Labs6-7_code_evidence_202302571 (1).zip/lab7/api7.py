"""Small API over the PostgreSQL data tier, used for the connection-pool stress tests (served with waitress)."""
import os, re, threading, time
import psycopg
from flask import Flask, jsonify, request
import db, repo, settings7

app = Flask(__name__)
POOL = db.make_pool(name="mu_pool")
SID = re.compile(r"^[0-9]{9}$")

def bad(msg, code=400): return jsonify({"type": "about:blank", "title": "Bad Request", "status": code, "detail": msg}), code

@app.get("/api/v1/pg/students/<sid>/history")
def history(sid):
    if not SID.fullmatch(sid): return bad("student id must be 9 digits")
    rows = repo.history(POOL, sid)
    return jsonify([{"id": r[0], "in": r[1].isoformat(), "floor": r[3], "seat": r[4]} for r in rows])

@app.get("/api/v1/pg/naive/<sid>/history")
def naive_history(sid):
    """Anti-pattern kept for comparison: a brand-new connection (TCP + auth) for every request."""
    if not SID.fullmatch(sid): return bad("student id must be 9 digits")
    with psycopg.connect(db.CFG["DATABASE_URL"]) as c:
        rows = c.execute(repo.Q_HISTORY, (sid,)).fetchall()
    return jsonify([{"id": r[0]} for r in rows])

@app.get("/api/v1/pg/floors")
def floors():
    rows = repo.floor_visits(POOL, "2026-10-01", "2026-10-08")
    return jsonify([{"floor": r[0], "visits": r[1]} for r in rows])

def _rss_mb():
    for l in open("/proc/self/status"):
        if l.startswith("VmRSS"): return round(int(l.split()[1]) / 1024, 1)

@app.get("/api/v1/pg/pool")
def pool_stats():
    s = POOL.get_stats()
    with POOL.connection() as c:
        n = c.execute("SELECT count(*) FROM pg_stat_activity WHERE application_name = 'mu_pool'").fetchone()[0]
    return jsonify({**s, "server_connections_from_this_pool": n, "rss_mb": _rss_mb()})

if __name__ == "__main__":
    from waitress import serve
    serve(app, host="127.0.0.1", port=int(os.environ.get("PORT", 8090)), threads=32)
