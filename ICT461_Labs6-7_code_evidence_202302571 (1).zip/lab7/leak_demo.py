"""Connection leak demo (Lecture 7, slide 19): leaky code starves the pool; the finally-pattern does not."""
import time, db, psycopg_pool
from repo import Q_HISTORY
pool = db.make_pool(min_size=1, max_size=3, name="leak_demo"); pool.timeout = 1.0

def leaky(sid):
    conn = pool.getconn()                       # checked out ...
    conn.execute(Q_HISTORY, ("not-a-number-%",)) if False else None
    raise RuntimeError("unhandled error before putconn()")     # ... and never returned

def safe(sid):
    conn = pool.getconn()
    try:
        raise RuntimeError("same error")
    finally:
        pool.putconn(conn)                      # always returned

print("== leaky handler, pool max_size=3, acquire timeout 1 s ==")
for i in range(1, 6):
    t = time.time()
    try: leaky("x")
    except RuntimeError: print(f"call {i}: handler failed (expected); {pool.get_stats().get('pool_available')} connections available")
    except psycopg_pool.PoolTimeout: print(f"call {i}: PoolTimeout after {time.time()-t:.1f}s -> pool is starved, every request would now hang or fail")
print("stats:", {k: v for k, v in pool.get_stats().items() if k in ("pool_size", "pool_available", "requests_waiting", "requests_errors")})
pool.close()
pool = db.make_pool(min_size=1, max_size=3, name="leak_demo"); pool.timeout = 1.0
print("\n== same failures with try/finally ==")
ok = 0
for i in range(50):
    try: safe("x")
    except RuntimeError: ok += 1
time.sleep(0.5)   # let the pool finish resetting returned connections
print(f"50 failing calls handled, {pool.get_stats().get('pool_available')} of {pool.get_stats().get('pool_size')} connections available afterwards, requests_errors={pool.get_stats().get('requests_errors', 0)}")
pool.close()
