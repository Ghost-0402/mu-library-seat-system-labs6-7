import settings7
from alembic import context
from sqlalchemy import create_engine, pool

cfg = settings7.load()
url = cfg["DATABASE_URL"].replace("postgresql://", "postgresql+psycopg://", 1)   # credentials come only from .env

def run():
    engine = create_engine(url, poolclass=pool.NullPool)
    with engine.connect() as conn:
        context.configure(connection=conn, target_metadata=None)
        with context.begin_transaction():       # transactional DDL: a failed migration leaves no half-built schema
            context.run_migrations()
run()
