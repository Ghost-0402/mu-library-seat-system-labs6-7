"""core tables: students, seats, reservations, audit_log, daily_occupancy

Revision ID: 0001
Revises:
"""
from alembic import op
import sqlalchemy as sa

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

FLOORS = (("ground", "G"), ("first", "F"), ("second", "S"))

def upgrade():
    op.create_table("students",
        sa.Column("student_id", sa.String(9), primary_key=True),
        sa.Column("full_name", sa.String(60), nullable=False),
        sa.Column("course", sa.String(80), nullable=False, server_default="Not specified"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.CheckConstraint("student_id ~ '^[0-9]{9}$'", name="ck_students_id_nine_digits"))
    op.create_table("seats",
        sa.Column("id", sa.Integer, sa.Identity(), primary_key=True),
        sa.Column("floor", sa.String(10), nullable=False),
        sa.Column("seat_number", sa.String(4), nullable=False),
        sa.Column("status", sa.String(15), nullable=False, server_default="free"),
        sa.UniqueConstraint("floor", "seat_number", name="uq_seats_floor_number"),
        sa.CheckConstraint("floor IN ('ground','first','second')", name="ck_seats_floor"),
        sa.CheckConstraint("status IN ('free','out_of_service')", name="ck_seats_status"))
    op.create_table("reservations",
        sa.Column("id", sa.BigInteger, sa.Identity(), primary_key=True),
        sa.Column("student_id", sa.String(9), sa.ForeignKey("students.student_id", ondelete="RESTRICT"), nullable=False),
        sa.Column("seat_id", sa.Integer, sa.ForeignKey("seats.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("checked_in_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("checked_out_at", sa.DateTime(timezone=True)),
        sa.Column("status", sa.String(10), nullable=False, server_default="active"),
        sa.Column("planned_minutes", sa.SmallInteger, nullable=False, server_default="120"),
        sa.CheckConstraint("status IN ('active','completed')", name="ck_res_status"),
        sa.CheckConstraint("planned_minutes BETWEEN 15 AND 180", name="ck_res_minutes"),
        sa.CheckConstraint("checked_out_at IS NULL OR checked_out_at >= checked_in_at", name="ck_res_time_order"))
    # Consistency enforced by the database itself: one active reservation per seat and per student
    op.create_index("uq_res_one_active_per_seat", "reservations", ["seat_id"], unique=True, postgresql_where=sa.text("status = 'active'"))
    op.create_index("uq_res_one_active_per_student", "reservations", ["student_id"], unique=True, postgresql_where=sa.text("status = 'active'"))
    op.create_table("audit_log",
        sa.Column("id", sa.BigInteger, sa.Identity(), primary_key=True),
        sa.Column("reservation_id", sa.BigInteger, sa.ForeignKey("reservations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("action", sa.String(20), nullable=False),
        sa.Column("at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")))
    op.create_table("daily_occupancy",
        sa.Column("day", sa.Date, primary_key=True),
        sa.Column("checkins", sa.Integer, nullable=False, server_default="0"),
        sa.CheckConstraint("checkins >= 0", name="ck_occ_nonneg"))
    seats = sa.table("seats", sa.column("floor", sa.String), sa.column("seat_number", sa.String))
    op.bulk_insert(seats, [{"floor": f, "seat_number": f"{p}{n}"} for f, p in FLOORS for n in range(1, 41)])

def downgrade():
    for t in ("daily_occupancy", "audit_log", "reservations", "seats", "students"):
        op.drop_table(t)
