"""B-Tree indexes for the hot read paths (added after the baseline benchmark)

Revision ID: 0002
Revises: 0001
"""
from alembic import op
import sqlalchemy as sa

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

def upgrade():
    # composite: equality column first, sort column second (leftmost-prefix rule)
    op.create_index("ix_res_student_checkin", "reservations", ["student_id", sa.text("checked_in_at DESC")])
    op.create_index("ix_res_checkin", "reservations", ["checked_in_at"])
    op.create_index("ix_res_seat_checkin", "reservations", ["seat_id", "checked_in_at"])
    op.create_index("ix_audit_reservation", "audit_log", ["reservation_id"])

def downgrade():
    for n, t in (("ix_audit_reservation", "audit_log"), ("ix_res_seat_checkin", "reservations"), ("ix_res_checkin", "reservations"), ("ix_res_student_checkin", "reservations")):
        op.drop_index(n, table_name=t)
