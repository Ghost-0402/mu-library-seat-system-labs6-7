"""Connection pool (psycopg_pool). Pool sizing and timeouts come from the environment (see .env.example)."""
import settings7
from psycopg_pool import ConnectionPool

CFG = settings7.load()
def make_pool(min_size=None, max_size=None, name="mu_pool"):
    return ConnectionPool(
        CFG["DATABASE_URL"],
        min_size=int(CFG["POOL_MIN"]) if min_size is None else min_size,     # warm connections kept open
        max_size=int(CFG["POOL_MAX"]) if max_size is None else max_size,     # hard cap on server connections
        timeout=float(CFG["POOL_TIMEOUT_SECONDS"]),                           # acquire timeout: fail fast when exhausted
        max_idle=float(CFG["POOL_MAX_IDLE_SECONDS"]),                         # close surplus idle connections after this
        max_lifetime=1800, name=name, open=True,
        kwargs={"application_name": name})
