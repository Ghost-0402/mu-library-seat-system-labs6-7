"""Task 3 evidence: EXPLAIN (ANALYZE, BUFFERS) plus a 40-run latency benchmark for the three hot queries.
usage: python explain_bench.py <label> <out.json>"""
import json, statistics, sys, time, psycopg, settings7, repo
cfg = settings7.load(); label, out = sys.argv[1], sys.argv[2]
QUERIES = {
 "Q1 student history (equality + ORDER BY ... LIMIT 20)": (repo.Q_HISTORY, ("202202501",)),
 "Q2 visits per floor, 7-day range (JOIN + GROUP BY)": (repo.Q_FLOORS, ("2026-10-01", "2026-10-08")),
 "Q3 usage of one seat (FK lookup on seat_id)": (repo.Q_SEAT_USAGE, (57,)),
}
res = {}
with psycopg.connect(cfg["DATABASE_URL"], autocommit=True) as c:
    c.execute("ANALYZE")
    print(f"########## {label} ##########")
    for name, (sql, params) in QUERIES.items():
        print(f"\n--- {name}")
        plan = [r[0] for r in c.execute("EXPLAIN (ANALYZE, BUFFERS) " + sql, params).fetchall()]
        for l in plan:
            if any(k in l for k in ("Scan", "Index", "Sort", "Join", "Aggregate", "Gather", "Buffers: shared", "Planning Time", "Execution Time", "Rows Removed")): print("   " + l.strip()[:170])
        ex = [float(l.split(":")[1].split()[0]) for l in plan if l.strip().startswith("Execution Time")][0]
        scan = next((l.strip().split("  (")[0].replace("->  ", "") for l in plan if "Scan" in l and "reservations" in l), "?")
        for _ in range(5): c.execute(sql, params).fetchall()          # warm-up
        t = []
        for _ in range(40):
            s = time.perf_counter(); c.execute(sql, params).fetchall(); t.append((time.perf_counter() - s) * 1000)
        t.sort(); res[name] = {"scan": scan, "explain_ms": ex, "p50_ms": round(statistics.median(t), 3), "p95_ms": round(t[37], 3)}
        print(f"   => plan: {scan} | EXPLAIN ANALYZE {ex} ms | 40 runs: p50 {res[name]['p50_ms']} ms, p95 {res[name]['p95_ms']} ms")
json.dump(res, open(out, "w"), indent=1)
