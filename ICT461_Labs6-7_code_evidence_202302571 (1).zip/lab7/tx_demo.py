"""Task 2 evidence: ACID transactions with BEGIN / COMMIT / ROLLBACK, run against the live database."""
import threading, psycopg, db, repo
pool = db.make_pool(max_size=10, name="tx_demo")
def counts():
    with pool.connection() as c:
        r = c.execute("""SELECT (SELECT count(*) FROM reservations WHERE status='active'),
                                (SELECT count(*) FROM audit_log),
                                (SELECT coalesce(sum(checkins),0) FROM daily_occupancy)""").fetchone()
    return {"active_reservations": r[0], "audit_rows": r[1], "daily_counter": int(r[2])}
def show(t, extra=""): print(f"{t:<60} {counts()} {extra}")
with pool.connection() as c: c.execute("TRUNCATE audit_log, daily_occupancy"); c.execute("DELETE FROM reservations WHERE status='active'"); c.commit()
def one(sql):
    with pool.connection() as c: return c.execute(sql).fetchone()[0]
print("transaction_isolation:", one("SHOW transaction_isolation"), "(PostgreSQL default)\n")
show("T0 start")
rid = repo.reserve_seat(pool, "202202001", "ground", "G10"); show("T1 reserve G10 for 202202001 -> COMMIT", f"reservation id {rid}")
for fa, label in (("reservation", "T2 crash AFTER inserting the reservation"), ("audit", "T3 crash AFTER inserting the audit row")):
    try: repo.reserve_seat(pool, "202202002", "ground", "G11", fail_after=fa)
    except repo.InjectedFailure as e: print(f"   {label}: {e} -> ROLLBACK")
    show(label.split(" ")[0] + " counters after rollback (must equal T1)")
with pool.connection() as c:
    print("   G11 still free and no row for 202202002:", c.execute("SELECT status FROM seats WHERE floor='ground' AND seat_number='G11'").fetchone()[0], "/", c.execute("SELECT count(*) FROM reservations WHERE student_id='202202002' AND status='active'").fetchone()[0], "rows")
try: repo.reserve_seat(pool, "202202001", "first", "F5")
except repo.AlreadyCheckedIn as e: print("   T4 same student books a second seat -> unique index rejects it -> ROLLBACK:", type(e).__name__)
show("T4 counters (unchanged)")
try: repo.reserve_seat(pool, "202202003", "ground", "G10")
except repo.SeatUnavailable as e: print("   T5 different student books occupied G10 -> rejected:", e)
show("T5 counters (unchanged)")
# T6 concurrency: 30 students race for one seat
res = []
def race(i):
    try: repo.reserve_seat(pool, f"2022{3000+i:05d}", "second", "S20"); res.append("ok")
    except repo.SeatUnavailable: res.append("seat taken")
    except Exception as e: res.append(type(e).__name__)
ts = [threading.Thread(target=race, args=(i,)) for i in range(30)]
[t.start() for t in ts]; [t.join() for t in ts]
with pool.connection() as c: n = c.execute("SELECT count(*) FROM reservations r JOIN seats s ON s.id=r.seat_id WHERE s.seat_number='S20' AND r.status='active'").fetchone()[0]
print(f"\nT6 30 concurrent bookings of S20: {res.count('ok')} succeeded, {res.count('seat taken')} rejected, other errors {len([x for x in res if x not in ('ok','seat taken')])}; active rows for S20 = {n}")
show("T6 counters")
# T7 isolation: no dirty read
a = psycopg.connect(db.CFG["DATABASE_URL"], autocommit=True); b = psycopg.connect(db.CFG["DATABASE_URL"], autocommit=True)
a.execute("BEGIN"); a.execute("UPDATE seats SET status='out_of_service' WHERE floor='ground' AND seat_number='G30'")
seen = b.execute("SELECT status FROM seats WHERE floor='ground' AND seat_number='G30'").fetchone()[0]
print(f"\nT7 session A updated G30 to out_of_service (uncommitted); session B reads: {seen!r}  -> no dirty read")
a.execute("ROLLBACK"); a.close(); b.close()
print("   session A rolled back; G30 is", one("SELECT status FROM seats WHERE seat_number='G30'"))
repo.release_seat(pool, "202202001"); show("T8 release 202202001 (update + audit in one transaction)")
pool.close()
