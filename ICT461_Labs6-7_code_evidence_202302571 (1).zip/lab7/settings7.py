"""Environment schema for the data tier (fail-secure like Lab 6): no DATABASE_URL, no start."""
import os, re, sys

def _load(path):
    if os.path.exists(path):
        for l in open(path, encoding="utf-8"):
            l = l.strip()
            if l and not l.startswith("#") and "=" in l:
                k, v = l.split("=", 1); os.environ.setdefault(k.strip(), v.strip())

def load(dotenv=None):
    _load(dotenv or os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))
    rules = {"DATABASE_URL": lambda v: re.fullmatch(r"postgres(ql)?://[^:@/]+:[^@/]+@[\w.\-]+:\d+/\w+", v) is not None,
             "POOL_MIN": lambda v: v.isdigit() and 0 <= int(v) <= 50, "POOL_MAX": lambda v: v.isdigit() and 1 <= int(v) <= 100,
             "POOL_TIMEOUT_SECONDS": lambda v: v.replace(".", "", 1).isdigit(), "POOL_MAX_IDLE_SECONDS": lambda v: v.isdigit()}
    bad = [k for k, ok in rules.items() if not os.environ.get(k) or not ok(os.environ[k])]
    if bad:
        sys.stderr.write("Refusing to start; missing or invalid: " + ", ".join(bad) + "\n"); sys.exit(1)
    if int(os.environ["POOL_MIN"]) > int(os.environ["POOL_MAX"]):
        sys.stderr.write("Refusing to start; POOL_MIN must not exceed POOL_MAX\n"); sys.exit(1)
    return {k: os.environ[k] for k in rules}
