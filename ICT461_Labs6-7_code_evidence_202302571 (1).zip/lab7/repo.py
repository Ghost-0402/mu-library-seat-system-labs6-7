"""Repository layer: every statement is parameterised (%s placeholders), every multi-step write is one transaction."""
import psycopg
from psycopg import errors

class SeatUnavailable(Exception): pass
class AlreadyCheckedIn(Exception): pass
class UnknownStudent(Exception): pass
class InjectedFailure(Exception): pass

# ---------- read paths used by the benchmarks and the API ----------
Q_HISTORY = """SELECT r.id, r.checked_in_at, r.checked_out_at, s.floor, s.seat_number
               FROM reservations r JOIN seats s ON s.id = r.seat_id
               WHERE r.student_id = %s ORDER BY r.checked_in_at DESC LIMIT 20"""
Q_FLOORS = """SELECT s.floor, count(*) AS visits
              FROM reservations r JOIN seats s ON s.id = r.seat_id
              WHERE r.checked_in_at >= %s AND r.checked_in_at < %s
              GROUP BY s.floor ORDER BY s.floor"""
Q_SEAT_USAGE = "SELECT count(*), max(checked_in_at) FROM reservations WHERE seat_id = %s"

def history(pool, student_id):
    with pool.connection() as conn:                 # checked out here, returned automatically on exit (even on error)
        return conn.execute(Q_HISTORY, (student_id,)).fetchall()

def floor_visits(pool, start, end):
    with pool.connection() as conn:
        return conn.execute(Q_FLOORS, (start, end)).fetchall()

# ---------- transactional writes ----------
def reserve_seat(pool, student_id, floor, seat_number, minutes=120, fail_after=None):
    """Atomically: lock the seat, create the reservation, write the audit row, bump the daily counter.
    fail_after ('reservation' | 'audit') raises on purpose so the tests can prove that ROLLBACK undoes earlier steps."""
    with pool.connection() as conn:
        conn.autocommit = True                      # we issue BEGIN / COMMIT / ROLLBACK ourselves
        cur = conn.cursor()
        try:
            cur.execute("BEGIN")
            seat = cur.execute("SELECT id, status FROM seats WHERE floor = %s AND seat_number = %s FOR UPDATE",
                               (floor, seat_number)).fetchone()          # row lock: concurrent bookings of this seat queue here
            if seat is None or seat[1] != "free":
                raise SeatUnavailable(f"{seat_number} does not exist or is out of service")
            if cur.execute("SELECT 1 FROM students WHERE student_id = %s", (student_id,)).fetchone() is None:
                raise UnknownStudent(student_id)
            rid = cur.execute("""INSERT INTO reservations (student_id, seat_id, planned_minutes)
                                 VALUES (%s, %s, %s) RETURNING id""", (student_id, seat[0], minutes)).fetchone()[0]
            if fail_after == "reservation": raise InjectedFailure("simulated crash after step 3")
            cur.execute("INSERT INTO audit_log (reservation_id, action) VALUES (%s, 'check_in')", (rid,))
            if fail_after == "audit": raise InjectedFailure("simulated crash after step 4")
            cur.execute("""INSERT INTO daily_occupancy (day, checkins) VALUES (current_date, 1)
                           ON CONFLICT (day) DO UPDATE SET checkins = daily_occupancy.checkins + 1""")
            cur.execute("COMMIT")
            return rid
        except errors.UniqueViolation as e:
            cur.execute("ROLLBACK")
            name = e.diag.constraint_name or ""
            raise (SeatUnavailable("seat already occupied") if "per_seat" in name else AlreadyCheckedIn(student_id)) from None
        except BaseException:
            cur.execute("ROLLBACK")                 # undo every earlier step
            raise
        finally:
            conn.autocommit = False

def release_seat(pool, student_id):
    with pool.connection() as conn:
        conn.autocommit = True
        cur = conn.cursor()
        try:
            cur.execute("BEGIN")
            row = cur.execute("""UPDATE reservations SET status='completed', checked_out_at=now()
                                 WHERE student_id=%s AND status='active' RETURNING id""", (student_id,)).fetchone()
            if row is None: raise SeatUnavailable("no active reservation")
            cur.execute("INSERT INTO audit_log (reservation_id, action) VALUES (%s, 'check_out')", (row[0],))
            cur.execute("COMMIT"); return row[0]
        except BaseException:
            cur.execute("ROLLBACK"); raise
        finally:
            conn.autocommit = False
