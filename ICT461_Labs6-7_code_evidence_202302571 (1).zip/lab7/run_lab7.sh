#!/bin/bash
# Reproduces all Lab 7 evidence. Needs PostgreSQL running and .env set (see README).
cd "$(dirname "$0")"; export PYTHONPATH=$PWD; EV=../evidence; A="alembic -c alembic.ini"
DB_URL=$(grep -E "^DATABASE_URL=" .env | cut -d= -f2-)
PSQL="psql $DB_URL"
{
echo "######## Task 1: migration engine (Alembic), up/down, version table"
echo "\$ alembic downgrade base"; $A downgrade base; echo "\$ alembic current"; $A current; echo "(empty: no schema version)"
echo "\$ alembic upgrade 0001"; $A upgrade 0001; $A current
echo "\$ psql -c '\\dt'"; $PSQL -c "\\dt"
echo "\$ psql -c '\\d reservations'"; $PSQL -c "\\d reservations"
echo "\$ psql -c 'select * from alembic_version; select count(*) seats from seats;'"; $PSQL -c "select * from alembic_version" -c "select count(*) as seats from seats"
echo "\$ alembic upgrade head   (adds the B-Tree indexes)"; $A upgrade head; $A current
echo "\$ alembic history"; $A history
echo "\$ psql -c '\\di'  (indexes on reservations)"; $PSQL -c "select indexname, indexdef from pg_indexes where tablename='reservations' order by 1"
echo "\$ alembic downgrade -1   (roll back one version)"; $A downgrade -1; $A current
$PSQL -c "select indexname from pg_indexes where tablename='reservations' order by 1"
echo "\$ alembic downgrade base   (roll back everything)"; $A downgrade base; $PSQL -c "\\dt"
echo "\$ alembic upgrade 0001   (forward again, indexes not yet created)"; $A upgrade 0001; $A current
} > $EV/migrations_log.txt 2>&1
python3 seed.py > $EV/seed_log.txt 2>&1; cat $EV/seed_log.txt
python3 explain_bench.py "BEFORE: schema 0001, no secondary indexes" $EV/bench_before.json > $EV/explain_before.txt 2>&1
{ echo "\$ alembic upgrade head"; $A upgrade head; $A current; } > $EV/migrate_indexes_log.txt 2>&1; $PSQL -c "ANALYZE" >/dev/null
python3 explain_bench.py "AFTER: schema 0002, B-Tree indexes" $EV/bench_after.json > $EV/explain_after.txt 2>&1
python3 tx_demo.py > $EV/transactions_log.txt 2>&1
python3 leak_demo.py > $EV/leak_log.txt 2>&1
python3 - <<'PY' > $EV/explain_summary.txt
import json
b, a = json.load(open("../evidence/bench_before.json")), json.load(open("../evidence/bench_after.json"))
print(f"{'Query':<58}{'Plan before':<34}{'Plan after':<44}{'p50 before':>11}{'p50 after':>10}{'speed-up':>9}")
for k in b:
    print(f"{k:<58}{b[k]['scan'][:32]:<34}{a[k]['scan'][:42]:<44}{b[k]['p50_ms']:>9.2f}ms{a[k]['p50_ms']:>8.2f}ms{b[k]['p50_ms']/a[k]['p50_ms']:>8.1f}x")
PY
cat $EV/explain_summary.txt
