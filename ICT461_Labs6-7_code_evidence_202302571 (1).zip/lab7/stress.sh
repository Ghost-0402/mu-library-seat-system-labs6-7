#!/bin/bash
# Task 4 evidence: Autocannon load test of the pooled API, a no-pool comparison, and pool statistics.
cd "$(dirname "$0")"; export PYTHONPATH=$PWD; EV=../evidence; AC=../tools/node_modules/.bin/autocannon
run() { # run <connections> <seconds> <url> : autocannon with a compact summary
  echo "\$ autocannon -c $1 -d $2 $3"; $AC -c $1 -d $2 -j $3 2>/dev/null | python3 -c "
import json,sys; d=json.load(sys.stdin); l=d['latency']; r=d['requests']
print(f'  requests: {r[\"total\"]:,} in {d[\"duration\"]} s   throughput avg: {r[\"average\"]:.0f} req/s')
print(f'  latency ms: avg {l[\"average\"]}  p50 {l[\"p50\"]}  p97.5 {l[\"p97_5\"]}  p99 {l[\"p99\"]}  max {l[\"max\"]}')
print(f'  2xx: {d[\"2xx\"]:,}   non-2xx: {d[\"non2xx\"]}   errors: {d[\"errors\"]}   timeouts: {d[\"timeouts\"]}   resets: {d[\"resets\"]}')"
}
DB_URL=$(grep -E "^DATABASE_URL=" .env | cut -d= -f2-); PSQL="psql $DB_URL -At"
pkill -f "api7.py" 2>/dev/null; sleep 1; (PORT=8090 nohup python3 api7.py > /tmp/api7.log 2>&1 &); sleep 3
U=http://127.0.0.1:8090/api/v1/pg
sampler() { # peak server-side connections while the load runs
  : > /tmp/peak.txt; while [ -f /tmp/sampling ]; do $PSQL -c "select count(*) from pg_stat_activity where application_name='mu_pool'" >> /tmp/peak.txt; sleep 0.5; done; }
{
echo "######## Pool settings in use (from .env): min=$(grep POOL_MIN .env | cut -d= -f2) max=$(grep POOL_MAX .env | cut -d= -f2) timeout=$(grep POOL_TIMEOUT .env | cut -d= -f2)s idle=$(grep POOL_MAX_IDLE .env | cut -d= -f2)s"
echo; echo "######## Before the load"; curl -s $U/pool | python3 -m json.tool | grep -E "pool_min|pool_max|pool_size|pool_available|requests_num|connections_num|server_conn|rss_mb"
touch /tmp/sampling; sampler & SP=$!
echo; echo "######## Load test 1: POOLED history endpoint, 100 concurrent connections for 15 s"
run 100 15 $U/students/202202501/history
echo; echo "######## During/after load"; curl -s $U/pool | python3 -m json.tool | grep -E "pool_size|pool_available|requests_num|requests_waiting|requests_wait_ms|requests_errors|connections_num|connections_lost|returns_bad|server_conn|rss_mb"
echo; echo "######## Load test 2: POOLED floor-aggregate (JOIN + range) endpoint, 100 connections, 10 s"
run 100 10 $U/floors
rm -f /tmp/sampling; sleep 0.5; wait $SP 2>/dev/null
echo; echo "Peak server-side connections seen by pg_stat_activity during load (pool max is $(grep POOL_MAX .env | cut -d= -f2) + 1 for the stats probe): $(sort -n /tmp/peak.txt | tail -1)"
echo; echo "######## Second pooled run with the pg_stat_activity sampler switched off"
run 100 10 $U/students/202202501/history
sleep 2; echo; echo "######## After the load (idle, 3 s later): connections returned, none leaked"
curl -s $U/pool | python3 -m json.tool | grep -E "pool_size|pool_available|requests_waiting|requests_errors|server_conn|rss_mb"
echo; echo "Server log lines containing error/traceback: $(grep -ciE "error|traceback" /tmp/api7.log)"
echo; echo "######## Comparison: NO pool (new connection per request), 100 connections, 10 s"
run 100 10 $U/naive/202202501/history
echo; echo "Server-side connections right after the no-pool run:"; $PSQL -c "select count(*) from pg_stat_activity where datname='mu_library'"
} > $EV/pool_stress_log.txt 2>&1
pkill -f "api7.py"; cat $EV/pool_stress_log.txt | cut -c1-200
