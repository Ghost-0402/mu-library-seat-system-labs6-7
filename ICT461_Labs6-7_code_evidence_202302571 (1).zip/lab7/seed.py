"""Seed realistic volume: 5,000 students and 1,000,000 completed reservations over the last 365 days (server-side generate_series)."""
import sys, time, psycopg, settings7
cfg = settings7.load(); n_res = int(sys.argv[1]) if len(sys.argv) > 1 else 1_000_000
with psycopg.connect(cfg["DATABASE_URL"], autocommit=True) as c:
    t = time.time()
    c.execute("TRUNCATE audit_log, reservations, students, daily_occupancy RESTART IDENTITY CASCADE")
    c.execute("""INSERT INTO students (student_id, full_name, course)
                 SELECT lpad((202200000 + g)::text, 9, '0'), 'Student ' || g, 'BSc Computer Science' FROM generate_series(1, 5000) g""")
    c.execute("""INSERT INTO reservations (student_id, seat_id, checked_in_at, checked_out_at, status, planned_minutes)
                 SELECT lpad((202200000 + 1 + floor(random()*5000)::int)::text, 9, '0'),
                        1 + floor(random()*120)::int, ts, ts + interval '90 minutes', 'completed', 90
                 FROM (SELECT now() - random() * interval '365 days' AS ts FROM generate_series(1, %s)) x""", (n_res,))
    c.execute("ANALYZE")
    n = c.execute("SELECT count(*) FROM reservations").fetchone()[0]
    print(f"seeded {n:,} reservations for 5,000 students in {time.time()-t:.1f}s")
