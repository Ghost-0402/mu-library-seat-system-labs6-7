const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'), path = require('path'); const out = [];
const log = (k, v) => { const s = k + ': ' + (typeof v === 'string' ? v : JSON.stringify(v)); out.push(s); console.log(s); };
const env = Object.fromEntries(fs.readFileSync('../app/.env', 'utf8').split('\n').filter(l => l.includes('=')).map(l => l.split(/=(.*)/s).slice(0, 2)));
(async () => {
  const b = await chromium.launch();
  // ---------- BEFORE: stored XSS fires in the librarian dashboard ----------
  { const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } }); const p = await ctx.newPage(); const dialogs = [];
    p.on('dialog', d => { dialogs.push(d.message()); d.dismiss(); });
    await p.goto('http://localhost:5001/admin'); await p.fill('#pin', 'MU2026'); await p.click('button'); await p.waitForTimeout(1500);
    await p.goto('http://localhost:5001/admin'); await p.waitForTimeout(2000);
    log('BEFORE_admin_stored_xss_executed', await p.evaluate(() => window.__pwned === 1));
    await p.screenshot({ path: 'x_before_admin.png' }); await ctx.close(); }
  // ---------- AFTER ----------
  const db = require('child_process').execSync(`python3 -c "
import sqlite3;c=sqlite3.connect('../app/library.db')
c.execute('''INSERT OR REPLACE INTO active_sessions(student_id,full_name,course,floor,seat_number,check_in_time,last_activity,status) VALUES ('202300555','<img src=x onerror=window.__pwned=1>','BSc','second','S9',datetime('now'),datetime('now'),'present')''');c.commit()"`);
  const ctx = await b.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1100, height: 900 }, geolocation: { latitude: -14.2962, longitude: 28.5605 }, permissions: ['geolocation'] });
  const p = await ctx.newPage(); const csp = [], resp = {};
  p.on('console', m => { if (/Content Security Policy|Refused/i.test(m.text())) csp.push(m.text().slice(0, 220)); });
  p.on('response', r => { if (r.url().endsWith('/') && !resp.main) resp.main = r.headers(); });
  await p.goto('https://localhost:8443/'); await p.waitForTimeout(1200);
  log('AFTER_home_csp_violations_on_load', csp.length);
  const hdr = resp.main; log('AFTER_headers', Object.fromEntries(['content-security-policy', 'x-content-type-options', 'referrer-policy', 'cross-origin-opener-policy', 'x-frame-options', 'strict-transport-security'].map(k => [k, (hdr[k] || '').slice(0, 400)])));
  const nonceInHtml = await p.evaluate(() => [...document.querySelectorAll('script,style')].filter(e => e.nonce).length); log('AFTER_elements_with_nonce', nonceInHtml);
  // full check-in through the real UI under the strict CSP
  await p.fill('#inp-sid', '202300666'); await p.fill('#inp-name', "Peter O'Neil"); await p.fill('#inp-course', 'BSc Computer Science');
  await p.click('text=Continue to GPS Verification'); await p.click('#gps-btn'); await p.waitForFunction(() => !document.getElementById('gps-next').disabled, null, { timeout: 8000 });
  await p.click('#gps-next'); await p.fill('#inp-seat', 'G22'); await p.click('.seat-confirm-btn'); await p.click('#checkin-btn');
  await p.waitForSelector('#sess-name', { state: 'visible', timeout: 8000 }); await p.waitForTimeout(1500);
  log('AFTER_ui_checkin_result', await p.textContent('#sess-name'));
  await p.screenshot({ path: 'x_after_student.png' });
  const ck = (await ctx.cookies()).find(c => c.name === 'seatToken'); log('AFTER_seatToken_cookie', { httpOnly: ck.httpOnly, secure: ck.secure, sameSite: ck.sameSite, path: ck.path });
  log('AFTER_js_sees_cookie', await p.evaluate(() => document.cookie));
  log('AFTER_active_list_text', (await p.textContent('#active-list')).replace(/\s+/g, ' ').slice(0, 160));
  // injected markup: CSP is the second layer
  await p.evaluate(() => { document.body.insertAdjacentHTML('beforeend', '<img src=x onerror="window.__pwned2=1">'); });
  await p.waitForTimeout(600); log('AFTER_injected_inline_handler_ran', await p.evaluate(() => window.__pwned2 === 1)); log('AFTER_csp_console_messages', csp);
  await p.evaluate(() => { const s = document.createElement('script'); s.textContent = 'window.__pwned3=1'; document.body.appendChild(s); });
  log('AFTER_injected_inline_script_ran', await p.evaluate(() => window.__pwned3 === 1));
  // admin dashboard with the stored payload
  await p.goto('https://localhost:8443/admin'); await p.fill('#pin', env.MU_ADMIN_PIN); await p.click('#go'); await p.waitForTimeout(1500);
  await p.goto('https://localhost:8443/admin'); await p.waitForTimeout(2500);
  log('AFTER_admin_stored_payload_executed', await p.evaluate(() => window.__pwned === 1));
  log('AFTER_admin_shows_payload_as_text', (await p.textContent('#active-list')).includes('<img src=x'));
  log('AFTER_admin_charts_rendered', await p.evaluate(() => typeof Chart !== 'undefined' && document.querySelectorAll('canvas').length));
  await p.screenshot({ path: 'x_after_admin.png' });
  await p.click('text=Log Out').catch(() => {}); 
  log('AFTER_total_csp_violations', csp.length);
  fs.writeFileSync('browser_lab6.txt', out.join('\n') + '\n'); await b.close();
})();
