#!/bin/bash
# Lab 6 / Task 4: secret scanning (TruffleHog), SAST (Bandit, detect-secrets) and dependency audit (pip-audit)
TF=${TRUFFLEHOG:-/tmp/tf/trufflehog}; R=$(cd "$(dirname "$0")/.." && pwd); W=$(mktemp -d)
mkdir -p $W/before $W/after
(cd $R/before && tar cf - --exclude=library.db --exclude=__pycache__ --exclude=certs/ca.key --exclude=certs/server.key --exclude=run_before.py .) | tar xf - -C $W/before
(cd $R/app && tar cf - --exclude=library.db --exclude=__pycache__ --exclude=certs/ca.key --exclude=certs/server.key .) | tar xf - -C $W/after
echo "######## 1. Git hygiene: is .env ignored and untracked? (AFTER)"
cd $W/after && git init -q && git config user.email a@b.c && git config user.name lab && git add -A && git commit -qm "after" 2>&1 | tail -1
echo "\$ ls -a | grep env";  ls -a | grep -E "^\.env"
echo "\$ git check-ignore -v .env";  git check-ignore -v .env
echo "\$ git ls-files | grep -E '(^|/)\.env'"; git ls-files | grep -E '(^|/)\.env'
echo "\$ git ls-files | grep -E '\.(key|db)$' (private keys and databases must not be tracked)"; git ls-files | grep -E '\.(key|db)$' || echo "(none tracked)"
cd $W/before && git init -q && git config user.email a@b.c && git config user.name lab && git add -A && git commit -qm "before" 2>&1 | tail -1
echo; echo "######## 2. TruffleHog on the git history (verified + unverified findings)"
for v in before after; do echo "\$ trufflehog git file://$v --no-update --no-verification"; (cd $W && $TF git file://$W/$v --no-update --no-verification 2>&1 | grep -vE '^\s*$' | tail -6); done
echo; echo "######## 3. detect-secrets (keyword + entropy detectors)"
for v in before after; do echo "\$ detect-secrets scan $v   (files with findings)"; (cd $W/$v && detect-secrets scan --exclude-files 'static/(vendor|swagger)/.*|templates/index\.html|certs/.*|tests/.*' 2>/dev/null | python3 -c "
import json,sys; d=json.load(sys.stdin)['results']
if not d: print('  clean: no findings')
for f,v in d.items():
    for x in v: print('  %s:%s  %s'%(f,x['line_number'],x['type']))"); done
echo; echo "######## 3b. git grep for the project's own known-bad defaults (hard-coded secret key and admin PIN)"
for v in before after; do echo "\$ git grep -nE 'mu-library-secret|MU2026' ($v)"; (cd $W/$v && git grep -nE 'mu-library-secret|MU2026' -- '*.py' '*.html' '*.md' | cut -c1-150 || true); (cd $W/$v && git grep -qE 'mu-library-secret|MU2026' -- '*.py' '*.html' || echo "  (no matches)"); done
echo; echo "######## 4. Bandit (Python SAST), medium severity and above"
for v in before after; do echo "\$ bandit -r $v -ll -q"; (cd $W && bandit -r $v -ll -q --exclude $v/tests 2>&1 | grep -E "Issue:|Severity|Location|No issues|Total issues|High:|Medium:" | head -24); done
echo; echo "######## 5. Dependency audit (pip-audit, the Python counterpart of npm audit)"
echo "\$ pip-audit -r requirements.txt"; cd $W/after && pip-audit -r requirements.txt 2>&1 | tail -8
