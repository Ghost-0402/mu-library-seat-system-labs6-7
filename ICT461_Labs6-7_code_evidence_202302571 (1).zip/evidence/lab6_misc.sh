#!/bin/bash
R=$(cd "$(dirname "$0")/.." && pwd); CA=$R/app/certs/ca.pem
echo "######## 1. Environment validation: the server refuses to start (fail-secure)"
cd $R/app; mkdir -p /tmp/noenv && cp config.py /tmp/noenv/
echo "\$ python app.py   # no .env, no environment variables"; (cd /tmp/noenv && python3 -c "import config; config.load_settings(dotenv_path='/nonexistent')"; echo "exit code: $?")
echo; echo "\$ MU_ADMIN_PIN=MU2026 ... python app.py   # the old hard-coded default is rejected"
(cd /tmp/noenv && MU_SECRET_KEY=$(python3 -c "print('k'*40)") MU_ADMIN_PIN=MU2026 APP_ENV=production DATABASE_PATH=library.db python3 -c "import config; config.load_settings(dotenv_path='/nonexistent')"; echo "exit code: $?")
echo; echo "\$ cat .env.example   # committed template, no values"; cat .env.example
echo; echo "\$ sed 's/=.*/=<hidden>/' .env   # the real .env stays local and git-ignored"; sed 's/=.*/=<hidden>/' .env
echo; echo "######## 2. Security regression tests"; echo "\$ python -m unittest tests.test_security -v"; python3 -W ignore -m unittest tests.test_security -v 2>&1 | grep -E "ok$|FAIL|ERROR|^Ran|^OK"
echo; echo "######## 3. HTTP response headers, BEFORE (Lab 5 code) and AFTER"
echo "\$ curl -sI http://localhost:5001/        # BEFORE"; curl -sI http://localhost:5001/ | tr -d '\r' | grep -iE "^HTTP|content-security|x-content-type|referrer|cross-origin|x-frame|strict-transport" || true; for h in Content-Security-Policy Cross-Origin-Opener-Policy X-Frame-Options; do curl -sI http://localhost:5001/ | grep -qi "^$h" || echo "$h: (absent)"; done
echo; echo "\$ curl -sI --cacert certs/ca.pem https://localhost:8443/        # AFTER"; curl -sI --cacert $CA https://localhost:8443/ | tr -d '\r' | grep -iE "^HTTP|content-security|x-content-type|referrer|cross-origin|x-frame|strict-transport" | sed 's/; /;\n      /g'
echo; echo "Nonce changes on every request:"; for i in 1 2 3; do curl -sI --cacert $CA https://localhost:8443/ | grep -io "nonce-[A-Za-z0-9_-]*" | head -1; done
