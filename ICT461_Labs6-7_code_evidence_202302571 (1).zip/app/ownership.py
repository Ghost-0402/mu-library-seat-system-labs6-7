"""Lab 6 / A01 (IDOR): a check-in is owned by whoever received its random seat token at check-in.
Every endpoint that acts on a student_id must prove ownership; the ID alone is never enough."""
import hashlib, hmac, secrets
from datetime import datetime, timedelta
from database import get_connection, MAX_SESSION_MINUTES

COOKIE = "seatToken"
def _h(t): return hashlib.sha256(t.encode()).hexdigest()

def init_ownership():
    conn = get_connection()
    conn.execute("""CREATE TABLE IF NOT EXISTS seat_tokens(
        student_id TEXT PRIMARY KEY, token_hash TEXT NOT NULL, expires_at TEXT NOT NULL)""")
    conn.commit(); conn.close()

def issue(student_id):
    token = secrets.token_urlsafe(32)
    exp = (datetime.now() + timedelta(minutes=MAX_SESSION_MINUTES + 30)).isoformat()
    conn = get_connection()
    conn.execute("INSERT OR REPLACE INTO seat_tokens VALUES (?,?,?)", (student_id, _h(token), exp))
    conn.commit(); conn.close(); return token

def owns(student_id, token):
    if not token or not student_id: return False
    conn = get_connection()
    r = conn.execute("SELECT token_hash, expires_at FROM seat_tokens WHERE student_id=?", (student_id,)).fetchone()
    conn.close()
    return bool(r) and datetime.now() < datetime.fromisoformat(r["expires_at"]) and hmac.compare_digest(r["token_hash"], _h(token))

def revoke(student_id):
    conn = get_connection(); conn.execute("DELETE FROM seat_tokens WHERE student_id=?", (student_id,)); conn.commit(); conn.close()
