#!/bin/bash
# Local CA + localhost certificate (ECDSA P-256), the OpenSSL equivalent of `mkcert localhost 127.0.0.1`.
# With mkcert installed you can instead run:  mkcert -install && mkcert -key-file certs/server.key -cert-file certs/server.pem localhost 127.0.0.1
set -e; cd "$(dirname "$0")"; mkdir -p certs; cd certs
openssl ecparam -name prime256v1 -genkey -noout -out ca.key
openssl req -x509 -new -key ca.key -sha256 -days 365 -subj "/CN=MU Library Local CA" -out ca.pem \
  -addext "basicConstraints=critical,CA:TRUE" -addext "keyUsage=critical,keyCertSign,cRLSign" -addext "subjectKeyIdentifier=hash"
openssl ecparam -name prime256v1 -genkey -noout -out server.key
openssl req -new -key server.key -subj "/CN=localhost" -out server.csr
printf "subjectAltName=DNS:localhost,IP:127.0.0.1\nbasicConstraints=CA:FALSE\nkeyUsage=digitalSignature\nextendedKeyUsage=serverAuth\nauthorityKeyIdentifier=keyid\nsubjectKeyIdentifier=hash\n" > ext.cnf
openssl x509 -req -in server.csr -CA ca.pem -CAkey ca.key -CAcreateserial -days 90 -sha256 -extfile ext.cnf -out server.pem
rm -f server.csr ext.cnf ca.srl
echo "Created certs/ca.pem (import into your browser/OS trust store), certs/server.pem, certs/server.key"
