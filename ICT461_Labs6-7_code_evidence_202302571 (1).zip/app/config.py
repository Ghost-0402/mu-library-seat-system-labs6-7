"""Lab 6 / Task 4: secrets live in the environment (.env), and the server refuses to start without them.
Python equivalent of the lecture's Zod schema on process.env (fail-secure principle)."""
import os, re, sys

WEAK = {"mu2026", "admin", "admin123", "password", "12345678", "changeme", "mu-library-secret-2026"}
SCHEMA = {  # name: (validator, help text)
    "MU_SECRET_KEY": (lambda v: len(v) >= 32 and v.lower() not in WEAK, "at least 32 characters (try: python -c \"import secrets;print(secrets.token_urlsafe(48))\")"),
    "MU_ADMIN_PIN": (lambda v: len(v) >= 8 and v.lower() not in WEAK, "at least 8 characters and not a known default"),
    "APP_ENV": (lambda v: v in ("development", "production"), "development or production"),
    "DATABASE_PATH": (lambda v: re.fullmatch(r"[\w./\\:-]+", v) is not None, "a file path such as library.db"),
}

def load_dotenv(path=".env"):
    """Minimal .env reader. Real environment variables win over the file."""
    if not os.path.exists(path): return
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line: continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

def load_settings(dotenv_path=None):
    load_dotenv(dotenv_path or os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))
    errors, out = [], {}
    for name, (ok, hint) in SCHEMA.items():
        v = os.environ.get(name)
        if v is None or v == "": errors.append(f"  - {name} is missing ({hint})")
        elif not ok(v): errors.append(f"  - {name} is invalid ({hint})")
        else: out[name] = v
    if errors:
        sys.stderr.write("Refusing to start: environment validation failed.\n" + "\n".join(errors) +
                         "\nCopy .env.example to .env and fill in real values.\n")
        sys.exit(1)
    return out
