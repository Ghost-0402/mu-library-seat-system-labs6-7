"""Serve the app over HTTPS with TLS 1.3 only (port 8443) and redirect HTTP (port 8080) to it."""
import os, ssl, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from werkzeug.serving import make_server
from app import app

HTTPS_PORT = int(os.environ.get("HTTPS_PORT", 8443)); HTTP_PORT = int(os.environ.get("HTTP_PORT", 8080))
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ctx.minimum_version = ssl.TLSVersion.TLSv1_3          # TLS 1.2 and older are refused
ctx.load_cert_chain("certs/server.pem", "certs/server.key")

class Redirect(BaseHTTPRequestHandler):
    def _go(self):
        self.send_response(308); self.send_header("Location", f"https://localhost:{HTTPS_PORT}{self.path}")
        self.send_header("Content-Length", "0"); self.end_headers()
    do_GET = do_POST = do_HEAD = _go
    def log_message(self, *a): pass

if __name__ == "__main__":
    threading.Thread(target=HTTPServer(("127.0.0.1", HTTP_PORT), Redirect).serve_forever, daemon=True).start()
    print(f"https://localhost:{HTTPS_PORT}  (TLS 1.3 only)   http://localhost:{HTTP_PORT} -> redirect", flush=True)
    make_server("127.0.0.1", HTTPS_PORT, app, ssl_context=ctx, threaded=True).serve_forever()
