document.getElementById("login-form").addEventListener("submit", async e => {
  e.preventDefault(); const f = e.target;
  const { status, data } = await api("POST", "/api/v1/auth/login", { student_id: f.student_id.value, password: f.password.value });
  if (status === 200) location.href = "/portal"; else showErrors(f, status, data);
});
document.getElementById("register-form").addEventListener("submit", async e => {
  e.preventDefault(); const f = e.target;
  const { status, data } = await api("POST", "/api/v1/users", { student_id: f.student_id.value, full_name: f.full_name.value, password: f.password.value });
  if (status === 201) { const b = f.querySelector(".msg"); b.textContent = "Account created. You can log in now."; b.className = "msg ok"; f.querySelectorAll(".err").forEach(x => x.textContent = ""); }
  else showErrors(f, status, data);
});
