"""Lab 6 / Task 3: strict CSP with a per-request nonce plus defence-in-depth headers (the Python counterpart of Helmet.js)."""
import secrets
from flask import g, request

def init_secure_http(app):
    @app.before_request
    def _nonce(): g.csp_nonce = secrets.token_urlsafe(16)
    @app.context_processor
    def _ctx(): return {"csp_nonce": g.get("csp_nonce", "")}
    @app.after_request
    def _headers(resp):
        n = g.get("csp_nonce", "")
        resp.headers["Content-Security-Policy"] = (
            f"default-src 'self'; script-src 'self' 'nonce-{n}'; object-src 'none'; base-uri 'none'; "
            f"frame-ancestors 'none'; form-action 'self'; img-src 'self' data:; connect-src 'self'; "
            f"style-src 'self' 'nonce-{n}' https://fonts.googleapis.com; style-src-attr 'unsafe-inline'; font-src https://fonts.gstatic.com")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        resp.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        if request.path.startswith(("/api", "/login", "/portal", "/admin")): resp.headers["Cache-Control"] = "no-store"
        return resp
