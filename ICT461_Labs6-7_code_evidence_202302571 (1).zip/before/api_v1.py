"""Versioned API (/api/v1). The pipeline reads openapi.yaml, so the spec drives validation and the docs."""
import json, os, threading, time, yaml
from flask import Blueprint, request, jsonify, g, make_response
from jsonschema import Draft202012Validator
import database as db
from database import FLOORS
from gps_utils import is_inside_library
import security as sec

bp = Blueprint("api_v1", __name__, url_prefix="/api/v1")
SPEC = yaml.safe_load(open(os.path.join(os.path.dirname(__file__), "openapi.yaml"), encoding="utf-8"))
CAPACITY = 120

# ---- operations table: (method, flask endpoint) -> (request schema name, needs auth, bucket)
OPS = {
    ("POST", "api_v1.create_user"):   ("UserCreate", False, "auth"),
    ("POST", "api_v1.login"):         ("LoginRequest", False, "auth"),
    ("POST", "api_v1.logout"):        (None, True, "auth"),
    ("GET",  "api_v1.me"):            (None, True, "api"),
    ("POST", "api_v1.create_checkin"):("CheckinCreate", True, "api"),
    ("DELETE","api_v1.release_seat"): (None, True, "api"),
}
LIMITS = {"auth": int(os.environ.get("RATE_LIMIT_AUTH", 10)), "api": int(os.environ.get("RATE_LIMIT_API", 100))}
WINDOW = int(os.environ.get("RATE_LIMIT_WINDOW", 60))
_hits, _lock = {}, threading.Lock()

def problem(status, title, slug, detail=None, errors=None):
    body = {"type": f"/problems/{slug}" if slug else "about:blank", "title": title, "status": status}
    if detail: body["detail"] = detail
    body["instance"] = request.path
    if errors: body["errors"] = errors
    r = make_response(json.dumps(body), status)
    r.headers["Content-Type"] = "application/problem+json"
    return r

def rate_limit(bucket):
    key, now = (bucket, request.remote_addr), time.time()
    with _lock:
        start, n = _hits.get(key, (now, 0))
        if now - start >= WINDOW: start, n = now, 0
        n += 1; _hits[key] = (start, n)
    limit, reset = LIMITS[bucket], int(start + WINDOW)
    g.rl = {"X-RateLimit-Limit": str(limit), "X-RateLimit-Remaining": str(max(0, limit - n)), "X-RateLimit-Reset": str(reset)}
    if n > limit:
        r = problem(429, "Too Many Requests", "rate-limit", f"Rate limit of {limit} requests per {WINDOW} seconds exceeded.")
        r.headers["Retry-After"] = str(max(1, reset - int(now)))
        return r

HINTS = {"student_id": "Must be exactly 9 digits.", "full_name": "Letters, spaces, hyphens and apostrophes only.",
         "seat_number": "Must be a seat like G12, F3 or S40 that matches the floor."}

def schema_errors(name, data):
    v = Draft202012Validator({"$ref": f"#/components/schemas/{name}", "components": SPEC["components"]})
    out = {}
    for e in sorted(v.iter_errors(data), key=lambda e: list(e.path)):
        f = ".".join(str(p) for p in e.path) or "(body)"
        k = e.validator
        if k == "required":
            for m in e.validator_value:
                if m not in data: out[m] = "This field is required."
            continue
        if k == "additionalProperties":
            for m in data:
                if m not in e.schema.get("properties", {}): out[m] = "Unknown field. Remove it from the request."
            continue
        msg = {"type": f"Must be of type {e.validator_value}.",
               "minLength": f"Must be at least {e.validator_value} characters.",
               "maxLength": f"Must be at most {e.validator_value} characters.",
               "minimum": f"Must be at least {e.validator_value}.", "maximum": f"Must be at most {e.validator_value}.",
               "enum": "Must be one of: " + ", ".join(map(str, e.validator_value if k == "enum" else [])) + ".",
               "uniqueItems": "Items must be unique.", "maxItems": f"At most {e.validator_value} items.",
               "pattern": HINTS.get(f.split(".")[0], "Invalid format.")}.get(k, "Invalid value.")
        out.setdefault(f, msg)           # never echo the submitted value
    return out

@bp.before_request
def pipeline():
    op = OPS.get((request.method, request.endpoint))
    bucket = op[2] if op else "api"
    r = rate_limit(bucket)
    if r: return r
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        origin = request.headers.get("Origin")
        if origin and origin != f"{request.scheme}://{request.host}":
            return problem(403, "Forbidden", "cross-origin", "Cross-origin requests are not allowed.")
    if not op: return
    schema, needs_auth, _ = op
    if needs_auth:
        g.user = sec.get_session_user(request.cookies.get(sec.SESSION_COOKIE))
        if not g.user:
            return problem(401, "Unauthorized", "unauthorized", "Log in to use this endpoint.")
    if schema:
        if not (request.mimetype == "application/json"):
            return problem(415, "Unsupported Media Type", "unsupported-media-type", "Content-Type must be application/json.")
        if request.content_length and request.content_length > 10_000:
            return problem(413, "Payload Too Large", "payload-too-large")
        try: data = json.loads(request.get_data() or b"")
        except ValueError: return problem(400, "Bad Request", "malformed-json", "The request body is not valid JSON.")
        if not isinstance(data, dict): return problem(422, "Unprocessable Entity", "validation-error", "Body must be a JSON object.")
        errs = schema_errors(schema, data)
        if errs: return problem(422, "Unprocessable Entity", "validation-error", f"{len(errs)} field(s) violate the schema.", errs)
        g.body = data

def _set_cookie(resp, token):
    resp.set_cookie(sec.SESSION_COOKIE, token, max_age=sec.SESSION_TTL_SECONDS, httponly=True, secure=True, samesite="Strict", path="/")

@bp.post("/users")
def create_user():
    b = g.body
    if not sec.create_user(b["student_id"], b["full_name"].strip(), b["password"]):
        return problem(409, "Conflict", "duplicate-account", "An account for this student ID already exists.")
    return jsonify(student_id=b["student_id"], full_name=b["full_name"].strip()), 201

@bp.post("/auth/login")
def login():
    u = sec.verify_login(g.body["student_id"], g.body["password"])
    if not u: return problem(401, "Unauthorized", "invalid-credentials", "Invalid student ID or password.")
    resp = jsonify(u); _set_cookie(resp, sec.create_session(u["student_id"])); return resp

@bp.post("/auth/logout")
def logout():
    sec.destroy_session(request.cookies.get(sec.SESSION_COOKIE))
    resp = make_response("", 204)
    resp.set_cookie(sec.SESSION_COOKIE, "", expires=0, max_age=0, httponly=True, secure=True, samesite="Strict", path="/")
    return resp

@bp.get("/auth/me")
def me(): return jsonify(g.user)

@bp.get("/seats/<floor>")
def seats(floor):
    if floor not in FLOORS: return problem(404, "Not Found", "not-found", "No such floor.")
    return jsonify(floor=floor, seats=[{"seat_number": k, "status": v["status"]} for k, v in db.get_seat_states(floor).items()])

@bp.get("/occupancy")
def occupancy(): return jsonify(current=len(db.get_active_sessions()), capacity=CAPACITY)

@bp.post("/checkins")
def create_checkin():
    b, u = g.body, g.user
    if db.is_already_checked_in(u["student_id"]): return problem(409, "Conflict", "already-checked-in", "Already checked in.")
    if db.is_seat_out_of_service(b["floor"], b["seat_number"]): return problem(409, "Conflict", "seat-unavailable", "Seat is out of service.")
    if db.is_seat_taken(b["floor"], b["seat_number"]): return problem(409, "Conflict", "seat-unavailable", "Seat is already occupied.")
    r = db.checkin_student(u["student_id"], u["full_name"], "Not specified", b["floor"], b["seat_number"], None, None)
    if not r["success"]: return problem(409, "Conflict", "already-checked-in", r["error"])
    return jsonify(student_id=u["student_id"], floor=b["floor"], seat_number=b["seat_number"],
                   check_in_time=r["check_in_time"], planned_hours=b["planned_hours"]), 201

@bp.delete("/checkins/current")
def release_seat():
    r = db.checkout_student(g.user["student_id"], reason="manual")
    if not r["success"]: return problem(404, "Not Found", "not-found", "You are not checked in.")
    return "", 204

@bp.get("/openapi.json")
def openapi_json(): return jsonify(SPEC)

@bp.after_request
def add_rl(resp):
    for k, v in getattr(g, "rl", {}).items(): resp.headers.setdefault(k, v)
    return resp

def init_api(app):
    sec.init_security_tables()
    app.register_blueprint(bp)
    @app.errorhandler(404)
    def nf(e): return problem(404, "Not Found", "not-found", "No such resource.") if request.path.startswith("/api/v1") else e
    @app.errorhandler(405)
    def na(e): return problem(405, "Method Not Allowed", None, "This method is not allowed on this resource.") if request.path.startswith("/api/v1") else e
    @app.errorhandler(Exception)
    def boom(e):
        if request.path.startswith("/api/v1"):
            app.logger.exception(e); return problem(500, "Internal Server Error", "internal", "Something went wrong. Nothing was changed.")
        from werkzeug.exceptions import HTTPException
        if isinstance(e, HTTPException): return e
        raise e
    @app.after_request
    def hdrs(resp):
        resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "no-referrer"
        if request.path in ("/login", "/portal", "/api-docs"):
            resp.headers["Content-Security-Policy"] = ("default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
                "script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            resp.headers["Cache-Control"] = "no-store"
        return resp
